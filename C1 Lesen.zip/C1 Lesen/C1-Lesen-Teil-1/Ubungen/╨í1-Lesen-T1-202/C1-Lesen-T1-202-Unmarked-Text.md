#### Kleines Land ganz groß  

Wenn die Einwohnerzahl des Fürstentums Liechtenstein mit 39.000 (0) ___ überschaubar ist, hat es doch so einiges zu bieten.  
*[[Lesen-Teil-1-Adverb]]*  
	*a) auch*  
	*b) klein*  
	*c) nur*  
	*d) beinahe*

---

*[[Lesen-Teil-1-Präposition]]*  
Vielen ist der (1) ___ Schweiz angrenzende Mikrostaat vielleicht durch sein Bankwesen oder Steuerschlupflöcher bekannt.  
	*a) mit der*  
	*b) an die*  
	*c) neben der*  
	*d) gegen die*

*[[Lesen-Teil-1-Nomen]]*  
Jedoch versetzt es nicht wenige in (2) ___ , wenn sie erfahren, dass Armstrong & Co bei der bemannten Mondlandung 1969 auch die Liechtensteiner Nationalflagge bei sich trugen.  
	*a) Erstaunen*  
	*b) Überraschung*  
	*c) Verblüffung*  
	*d) Entsetzen*

*[[Lesen-Teil-1-Verb]]*  
In der Größe einer Zigarettenschachtel begleitete sie die Astronauten auf dem Weg ins All und wieder zurück, um die Liechtensteiner Balzers AG zu (3) ___ , die durch ihre Vakuumtechnik und in der Fertigung von Schutzschichten einen wesentlichen Beitrag zum Gelingen der Mondmission leistete.  
	*a) verehren*  
	*b) bedanken*  
	*c) würdigen*  
	*d) beehren*

---

*[[Lesen-Teil-1-Verb]]*  
Die Amtssprache im sechstkleinsten Land der Welt (als kleiner (4) ___ lediglich der Vatikan, Monaco, Nauru, Tuvalu und San Marino) ist Hochdeutsch zwar die Amtssprache, untereinander spricht man jedoch Alemannisch, was dem Schweizerdeutschen nahekommt und demzufolge für die Wienerin oder den Hamburger eine Herausforderung darstellen kann.  
	*a) erweisen sich*  
	*b) begeben sich*  
	*c) entstehen*  
	*d) bestehen*

*[[Lesen-Teil-1-Konjunktion]]*  
Im Parlament wird allerdings strikt die Amtssprache verwendet, auch um zu verdeutlichen, dass eine Abgeordnete spricht und nicht Lena von nebenan.  
Die Menschen kennen sich nämlich meist, (5) ___ das informelle „Du“ den Vorrang hat.  
	*a) warum*  
	*b) weil*  
	*c) da*  
	*d) weswegen*

*[[Lesen-Teil-1-Adjektiv]]*  
Das förmliche „Sie“, stets für die Anrede der Fürstenfamilie (6) ___ , wird im Alltag also wenig genutzt.  
	*a) bedacht*  
	*b) ausgesucht*  
	*c) entsprechend*  
	*d) vorgesehen*

---

*[[Lesen-Teil-1-Adjektiv]]*  
Ihre Residenz, das Schloss Vaduz aus dem 13. Jahrhundert, benannt nach der gleichnamigen Hauptstadt der Nation, ist für die Öffentlichkeit nicht (7) ___ .  
	*a) zugänglich*  
	*b) begehbar*  
	*c) verfügbar*  
	*d) erhältlich*

*[[Lesen-Teil-1-Adverb]]*  
Möchte man aber doch vor Ort einen Einblick in das fürstliche Leben gewinnen, so bietet das „Alte Kino“ dazu die Gelegenheit, in dem es eine kurze virtuelle Führung durch das Schloss gibt.  
Neben seiner Funktion als Wohnsitz der Fürstenfamilie ist das Schloss (8) ___ das Wahrzeichen der Hauptstadt.  
	*a) gegebenenfalls*  
	*b) somit*  
	*c) zudem*  
	*d) nichtsdestotrotz*