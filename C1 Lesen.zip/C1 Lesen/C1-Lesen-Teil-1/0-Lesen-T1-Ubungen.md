[[0-Lesen-T1-Ubungen]]

---

2023 Mit Erfolg Übungsbuch:
- [ ] [[C1-Lesen-T1-000-Text|000]] Roboter als Unterwasser-Müllsammler
    *[[C1-Lesen-T1-000-Loesung|Lösung]]* 
- [ ] [[C1-Lesen-T1-001-Text|001]] Meister des Geruchs  
    *[[C1-Lesen-T1-001-Loesung|Lösung]]* 

2023 Mit Erfolg Modellsätzen
- [ ] [[C1-Lesen-T1-100-Text|100]] WAS JUGENDSPRACHE AUSMACHT
    *[[C1-Lesen-T1-100-Loesung|Lösung]]* 
- [ ] [[C1-Lesen-T1-101-Text|101]] Das verraten die Gene des Pompejaners
    *[[C1-Lesen-T1-101-Loesung|Lösung]]* 
- [ ] [[C1-Lesen-T1-102-Text|102]] Was hilft gegen die Spanische Wegschnecke?
    *[[C1-Lesen-T1-102-Loesung|Lösung]]* 
- [ ] [[C1-Lesen-T1-103-Text|103]] Ist Film gleich Film?
    *[[C1-Lesen-T1-103-Loesung|Lösung]]* 

2023 Prüfungstraining
- [ ] [[C1-Lesen-T1-200-Text|200]] Zu gut für die Tonne  
    *[[C1-Lesen-T1-200-Loesung|Lösung]]* 
- [ ] [[C1-Lesen-T1-201-Text|201]] Das Neo-Biedermeier  
    *[[C1-Lesen-T1-201-Loesung|Lösung]]* 
- [ ] [[C1-Lesen-T1-202-Text|202]] 
    *[[C1-Lesen-T1-202-Loesung|Lösung]]* 

