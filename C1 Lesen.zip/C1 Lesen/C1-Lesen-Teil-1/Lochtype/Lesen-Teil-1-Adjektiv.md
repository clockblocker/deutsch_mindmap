[[0-Lesen-Teil-1-Lochtype]]

---
