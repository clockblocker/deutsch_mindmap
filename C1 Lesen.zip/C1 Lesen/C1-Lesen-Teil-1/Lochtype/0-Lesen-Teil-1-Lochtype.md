[[0-Lesen-Teil-1-Lochtype]]

---

- [[Lesen-Teil-1-Verb|Verb]]
- [[Lesen-Teil-1-Adjektiv|Adjektiv]]
- [[Lesen-Teil-1-Adverb|Adverb]]
- [[Lesen-Teil-1-Konjunktion|Konjunktion]]
- [[Lesen-Teil-1-Konnektor|Konnektor]]
- [[Lesen-Teil-1-Nomen|Nomen]]
- [[Lesen-Teil-1-Präposition|Präposition]]
- [[Lesen-Teil-1-Pronomen|Pronomen]]

