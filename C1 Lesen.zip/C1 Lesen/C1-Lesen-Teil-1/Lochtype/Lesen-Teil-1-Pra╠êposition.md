[[0-Lesen-Teil-1-Lochtype]]

---

*[[Lesen-Teil-1-Präposition]]*  
*[[C1-Lesen-T1-000-Text#^2|^]]* Die Ozeane unseres Planeten sind voller Plastikmüll – zwischen 26 und 66 Millionen Tonnen größere und kleinere [[Kunststoffreste]] befinden sich [[Schätzung]]en (1) [[zufolge]] im Meer. ^2

*a) gegenüber | towards*
*b) halber | half*  
*c) zufolge | according to*
*d) zuliebe |for the sake of*

