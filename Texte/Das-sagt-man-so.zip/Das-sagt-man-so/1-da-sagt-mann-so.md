[[0-root-da-sagt-mann-so|Back to list]]

---
---

Heute tragen nur noch wenige Menschen Hüte. Trotzdem gibt es viele Leute, die alles unter einen Hut bringen wollen, damit jeder zufrieden ist. Aber das kann manchmal ziemlich schwierig sein. 

Jedes Jahr im Frühling plant Familie Gopal-Schmidt ihren Sommerurlaub. Doch dieses Mal hat jedes Familienmitglied andere Vorstellungen davon, wie die Reise aussehen soll. 

Mutter Birgit möchte im Urlaub einen Tauchkurs machen. Vater Amal möchte in eine große Stadt fahren und dort viele Museen besuchen. Tochter Sunita hat vor Kurzem angefangen, Portugiesisch zu lernen, und will deshalb nach Portugal fliegen. Und ihr Bruder Nils erklärt, dass er auf keinen Fall in ein Flugzeug steigen wird. 

Mutter Birgit seufzt: „Wie sollen wir all diese Wünsche unter einen Hut bringen?“ 
„Tja“, meint ihr Mann, „die Kinder werden langsam erwachsen und haben ihren eigenen Kopf. Und eigentlich ist das ja ganz gut so.“

Ja, denkt die Mutter, sie sind längst keine kleinen Kinder mehr. Da einfallen|fällt ihr etwas ein: „Sag mal, Sunita hat doch diese Freundin in Portugal, die sie schon lange mal besuchen will …“ „Richtig“, stimmt ihr Mann zu. 

„Und Nils wollte in den Ferien sowieso ein paar Wochen jobben, um Geld für sein Schlagzeug zu verdienen. Vielleicht könnte er bei meiner Schwester wohnen und in ihrer Firma arbeiten.“

Die Eltern ansehen|sehen sich an. „Und wir beide? Wir machen mal wieder Urlaub zu zweit. So wie früher!“

https://learngerman.dw.com/de/alles-unter-einen-hut-bringen/l-19399823







🎩🧩🤹‍♂️ alles unter einen Hut bringen *Redewendung*
👖🤏 den Gürtel enger schnallen *Redewendung*
☁️7️⃣🥰 auf Wolke sieben schweben *Redewendung*
