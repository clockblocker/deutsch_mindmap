[[0-root-da-sagt-mann-so|Back to list]]

---
---

Manche Leute lassen sich nicht so einfach überzeugen. Wenn man erst Überzeugungsarbeit Leisten muss, um ein Ziel zu erreichen, können ein paar nette Worte nicht schaden. Denn wer bekommt nicht gern ein Kompliment?
  
Simon braucht ein bisschen mehr Budget für sein neues Projekt. Aber wird er es bekommen? Jannis, sein Chef, ist eigentlich ein netter Mensch, doch er eingehen|geht nicht gern Risiken ein. 

Manchmal sagt er Nein zu Dingen, die eigentlich ganz sinnvoll wären. Bestimmt wird er alle möglichen Einwände haben: Wo soll er das Geld herholen? Und wer garantiert ihm, dass Simon nicht wiederkommt und noch ein höheres Budget braucht? 

Simon muss also damit rechnen, dass Jannis seine Bitte ablehnen wird. Deshalb greift er zu einem kleinen Trick: Er schmiert seinem Chef Jemandem Honig um den Bart schmieren|Honig um den Bart.

Natürlich greift er nicht zu echtem Honig, sondern zu netten Worten und Komplimenten. Kurz: Er schmeichelt ihm. 

Jannis kenne das Geschäft ja besser als er, ein Mann mit seiner Erfahrung wisse ja, wie das ist. Mit etwas mehr Geld könne man neue Software kaufen und sich einen besseren Programmierer leisten. 

Am Ende sei das ja nur ein Gewinn für die Firma und Jannis könne endlich die Anerkennung bekommen, die er verdiene. 

Die Firma würde sich vor neuen Aufträgen nicht retten können. „Stopp!“, ruft Jannis. „Du bekommst ja dein Budget. Und jetzt aufhören|hör auf, mir Honig um den Bart zu schmieren. Natürlich sehe ich die Vorteile selbst. Ich arbeite ja schon lange in dieser Branche.“ 

Simon bedankt sich und verlässt zufrieden das Büro seines Chefs. Jannis lächelt. Er hat wieder eine gute Entscheidung getroffen.


 https://learngerman.dw.com/de/jemandem-honig-um-den-bart-schmieren/l-18745505/lm, bitten, schmieren