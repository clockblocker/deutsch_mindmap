[[0-root-da-sagt-mann-so|Back to list]]

---
---

Eigenlob stinkt

Eigenlob stinkt.md#^2|^ Selbstbewusste Menschen haben es leichter im Leben. Sie beeindrucken andere durch ihre Fähigkeiten und Talente. ^2

Eigenlob stinkt.md#^3|^ Aber wenn sie nur von sich reden und mit ihrem Können angeben, kann das die Umwelt auch ganz schön nerven. ^3

Eigenlob stinkt.md#^4|^ „Ich bin der beste Radfahrer dieser Stadt“, behauptet Peter. Lisa verdreht die Augen. ^4

Eigenlob stinkt.md#^5|^ Die Geschichten über Peters Radfahrkünste hat sie sich schon tausendmal anhören müssen. ^5

Wenn Peter am Wochenende mit dem Rad unterwegs gewesen ist, hat er am Montagmorgen in der Bahn ein einziges Thema: „Ich bin blitzschnell“, „Ich habe den schärfsten Gehörsinn der Welt“, „Keiner hat solche Reflexe wie ich“, „Ich bin der König der Straße“, 

Eigenlob stinkt.md#^1|^ „Ich habe das und jenes geschafft“, ^6

„100 Kilometer an einem Tag? Ja, das ist doch ganz leicht!“... 

Eigenlob stinkt.md#^6|^ Normalerweise tut Lisa so, als würde sie sich für Peters Erzählungen interessieren, und versucht, an was anderes zu denken. Aber heute verliert sie die Nerven. ^6

Eigenlob stinkt.md#^7|^ „Weißt du was, Peter? Eigenlob stinkt!“, sagt sie. Peter verstummt nachdenklich. Dann schnüffelt er an seinen Achseln. ^7

Eigenlob stinkt.md#^8|^ „Du, das muss mein neues Deodorant sein. Ich kaufe morgen direkt ein besseres!“ Lisa aufgeben|gibt auf. Manche Menschen sind einfach unverbesserlich. ^8

https://learngerman.dw.com/de/eigenlob-stinkt/l-18745502/lm
