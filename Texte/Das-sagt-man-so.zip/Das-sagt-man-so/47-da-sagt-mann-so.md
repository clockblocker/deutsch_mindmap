[[0-root-da-sagt-mann-so|Back to list]]

---
---

Unter einer Decke ist es warm und gemütlich. Was darunter passiert, kann man von Außen nicht sehen. Es bleibt geheim. Doch was bedeutet es, wenn mehrere Personen unter einer Decke stecken? Oft nichts Gutes…  

In einem kleinen Dorf wurde ein Koffer mit sehr viel Geld gestohlen. Zwei Polizisten ermitteln und befragen alle Einwohner des Ortes, aber keiner hat etwas gesehen. Und niemand weiß von dem Koffer.
  
Doch fast alle haben vor kurzer Zeit viel Geld ausgegeben. Einer hat sich ein neues Auto gekauft. Ein anderer hat den Garten umbauen lassen. Ein Dritter hat sich einen riesigen Fernseher gekauft. 
 
 Die beiden Polizisten finden das sehr verdächtig. 
 „Wie kann es sein, dass keiner etwas von dem Geldkoffer weiß? Wieso verrät keiner, wer den Koffer gestohlen hat?“, fragt der Polizist. 
 „Die stecken alle unter einer Decke“, sagt sein Kollege. 
 „Du meinst, das ganze Dorf steckt unter einer Decke?“, fragt der erste Polizist nach. Der Kollege nickt. 
 „Das ist ein ganz großes Verbrechen!“, da ist er sich sicher. 
 Die Polizisten stöhnen. Das klingt nach sehr viel Arbeit.

https://learngerman.dw.com/de/unter-einer-decke-stecken/l-19267524/lm
