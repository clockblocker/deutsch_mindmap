[[0-root-da-sagt-mann-so|Back to list]]

---
---

Das hat wahrscheinlich jeder schon mal erlebt: Man probiert etwas aus und es funktioniert nicht. Und dann noch mal. Und noch mal. Egal, wie man sich anstellt, es klappt nicht! Da muss der Wurm drin sein …
  
Uli hat ein Problem: Er hat sich vor drei Wochen einen neuen Rechner gekauft, das neueste und teuerste Modell. 

Aber irgendwie macht der Rechner nicht das, was er tun soll. Schon das Hochfahren klappt nicht immer, ein neuer Browser lässt sich nicht installieren, und dann ist da immer wieder diese seltsame Fehlermeldung. 

Eigentlich versteht Uli viel von Computern, aber hier ist er wirklich ratlos. Also bringt er den Rechner zurück in den Laden. 

Der Fachverkäufer im Computerladen ist zunächst nicht besonders freundlich. „Sind Sie ganz sicher, dass Sie alles richtig installiert haben?“, fragt er Uli, „unsere Kunden waren bisher immer zufrieden. Es hat sich niemand über dieses Modell beschwert.“ 

„Das kann ja sein“, sagt Uli, „aber bei mir scheint einfach der Wurm drin zu sein. Irgendwas ist hier fehlerhaft.“ Der Fachverkäufer erklärt sich schließlich bereit, den Rechner umzutauschen. Der neue Computer läuft problemlos. Kein Wurm weit und breit. Uli ist erleichtert.

https://learngerman.dw.com/de/da-ist-der-wurm-drin/l-19068047/lm

🐛🚫 da ist der Wurm drin *Redewendung*
🎩🧩🤹‍♂️ alles unter einen Hut bringen *Redewendung*
👖🤏 den Gürtel enger schnallen *Redewendung*
☁️7️⃣🥰 auf Wolke sieben schweben *Redewendung*
