[[0-root-da-sagt-mann-so|Back to list]]

---
---

https://learngerman.dw.com/de/einen-korb-bekommen/l-18745518/lm 

Was ist an einem Korb so schlimm?
Eigentlich gar nichts!
Körbe sind schön und praktisch.
Einen Korb voll mit Obst zu bekommen, ist zum Beispiel sehr schön.
Aber manche Körbe bekommt niemand gerne.

Mikael geht ans Telefon: „Hallo Anna, ach schön von dir zu hören!“ Er lässt das „schön“ bewusst ironisch klingen.
Er war mal in Anna verliebt, aber sie hat ihm einen Korb gegeben.
Damals wusste er noch nicht, dass sie auf Frauen steht.
Inzwischen sind sie gute Freunde.
Doch in den letzten Wochen hat sie sich kaum gemeldet.
Genauer gesagt: Seit sie mit Katharina zusammen ist.
„Muss Liebe schön sein“, hat Mikael gedacht und sich dabei ziemlich einsam gefühlt.
Jetzt erzählt Anna, was sie in letzter Zeit alles erlebt hat: Sie war mit Katharina in Paris, und es war so romantisch!
Katharina hat sie zum Klettern mitgenommen.
Ein tolles Hobby!
Das machen sie jetzt gemeinsam.
Dabei hat sie auch Katharinas Freunde kennengelernt.
Die sind alle wahnsinnig nett!
Heute wollte sie mit Katharina ins Konzert gehen.
Katharina liebt Beethoven.
Trotzdem hat sie gesagt, dass sie heute keine Zeit hat.
„Katharina meint, sie sollte mal wieder ihre Eltern besuchen“, erklärt Anna.
„Und da dachte ich, du hast vielleicht Lust, mit mir ins Konzert zu gehen.“ „Tut mir leid,“ sagt Mikael, „ich bin mit meiner Freundin verabredet.“ „Freundin?“, fragt Anna überrascht.
„Seit wann hast du denn eine Freundin?“ Mikael grinst.
„Das erzähle ich dir ein anderes Mal.
Ich muss jetzt los.“ Dann auflegen|legt er auf.
Anna ist einen Moment lang sprachlos.
Aber dann freut sie sich, dass ihr bester Freund wieder verliebt ist und dieses Mal keinen Korb bekommen hat.
 
