[[0-root-da-sagt-mann-so|Back to list]]

---
---

Einen Nagel gerade in die Wand schlagen: Das geht mit der richtigen Technik und einem guten Hammer. Man kann aber auch mit Worten den Nagel auf den Kopf treffen. Und auch dazu braucht man die richtigen Werkzeuge.**  
  
Den Nagel auf den Kopf treffen.md#^1|(Quelle: Den Nagel auf den Kopf treffen)
Katja ist Journalistin. Sie schreibt für eine regionale Zeitung in ihrer Heimatstadt Bonn. Ihre Artikel werden online veröffentlicht und auch auf Facebook gepostet. ^1

Den Nagel auf den Kopf treffen.md#^6|^ Katja lesen|liest gerne die Kommentar|Kommentare im Netz, denn die Meinung der Leser interessieren|interessiert sie.
 ^6

Den Nagel auf den Kopf treffen.md#^2|(Quelle: Den Nagel auf den Kopf treffen)
Seit gestern ist Katja aber ein kleiner Star. Sie hat einen Artikel über den Zustand der Bonner Schulen geschrieben. Sie kritisiert darin die Stadtverwaltung, weil sie nicht genug Geld in die Sanierung der Schulgebäude stecke.  ^2

Den Nagel auf den Kopf treffen.md#^3|(Quelle: Den Nagel auf den Kopf treffen)
Damit hat sie ein Thema angesprochen, das viele bewegt: Ihr Artikel wurde über 20.000 Mal geteilt und tausendfach kommentiert.  ^3

Den Nagel auf den Kopf treffen.md#^7|^ Die meisten User geben ihr recht. Die junge Mutter Marina Koch schreibt zum Beispiel:  ^7

Den Nagel auf den Kopf treffen.md#^5|(Quelle: Den Nagel auf den Kopf treffen)
„Liebe Katja, Sie treffen|treffen mit Ihrem Artikel wirklich den Nagel auf den Kopf. Ich kann Ihnen nur zustimmen: Die Stadt sollte viel mehr für unsere Kind|Kinder tun. Danke!“
 ^5


 https://learngerman.dw.com/de/den-nagel-auf-den-kopf-treffen/l-19042074/lm
