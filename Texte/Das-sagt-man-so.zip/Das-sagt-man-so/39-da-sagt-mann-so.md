[[0-root-da-sagt-mann-so|Back to list]]

---
---

Kirschen sind lecker. Doch man sollte aufpassen, mit wem man sie isst. Denn manche Leute sind so unfreundlich, dass sie einem die Wörter wie Kerne 1 ins Gesicht spucken. Mit ihnen ist eben nicht gut Kirschen essen.

Max ist mit seinem Kollegen auf dem Weg ins Büro. Heute wird sich ihr neuer Chef vorstellen. Als sie an ihrem Schreibtisch sitzen, kommt der neue Chef schon zur Tür herein. 

„Sie sind beide zwei Minuten zu spät. In Zukunft wird es das nicht mehr geben!“, ruft er. Max und sein Kollege stehen sofort auf. 

Der Chef ruft weiter: „Solange ich Ihr Boss bin, werden Sie mehr und härter arbeiten müssen. Sie werden oft erst spätabends 1 nach Hause kommen. Und bei mir werden Fehler sofort bestraft 1. Haben Sie das verstanden?“ 

Max und sein Kollege nicken. Der Chef will gehen. 
„Warten Sie! Sollen wir uns nicht erst mal vorstellen?“, sagt Max. „Sie sollen nicht reden, Sie sollen arbeiten!“, brüllt 1 der Chef und geht aus dem Zimmer. 

„Oh je, mit dem ist aber nicht gut Kirschen essen“, seufzt der Kollege. Max seufzt auch. Die nächsten Jahre werden wohl lang und schwer werden.

https://learngerman.dw.com/de/mit-jemandem-ist-nicht-gut-kirschen-essen/l-19267493/lm