[[0-root-da-sagt-mann-so|Back to list]]

---
---

 https://learngerman.dw.com/de/in-der-not-frisst-der-teufel-fliegen/l-19120283/lm