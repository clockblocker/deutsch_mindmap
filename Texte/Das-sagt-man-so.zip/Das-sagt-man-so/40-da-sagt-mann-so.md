[[0-root-da-sagt-mann-so|Back to list]]

---
---

Das Schwein hat es nicht leicht. In vielen Kulturen [gilt] es als unrein und faul. 

Will man jemanden beleidigen, bezeichnet man ihn schon mal als „Schwein“. Aber wenn jemand „Schwein hat“, ist das ein Grund zur Freude.
  
Alfred gehört zu den Menschen, die immer den Kick suchen. Er braucht Abenteuer 1 und Aufregung, weil er sich sonst schnell langweilt. Dazu passt auch sein Hobby: das Glücksspiel. 

Ob Sportwetten oder Roulette, Alfred liebt es, bis zum Schluss dem Ergebnis entgegenzufiebern. 

Seine Frau streitet sich deswegen regelmäßig mit ihm und ist langsam mit ihrer Geduld am Ende. Sie glaubt, dass Alfred bisher nur Glück gehabt hat und befürchtet, dass er irgendwann sein ganzes Geld verlieren wird. 

Alfred ist anderer Meinung. Er glaubt, dass er einfach ein guter Spieler ist. 

Neulich kommt er total aufgeregt nach Hause und ruft: „Barbara, stell dir vor, ich hatte heute beim Roulette fast alles verloren. Aber ich habe einfach weitergemacht und habe jetzt das Doppelte meines Einsatzes gewonnen!“ 

Alfreds Frau greift sich an den Kopf. „Alfred, du hast wieder mal Schwein gehabt!“ stöhnt sie genervt. 

„Aber das war jetzt das letzte Mal! Ich verbiete dir, jemals wieder ins Casino zu gehen. Denn wenn dich das Glück irgendwann im Stich lässt, trenne ich mich von dir.“

Ob Alfred verstanden hat, dass er schon wieder Schwein hatte? Eine letzte Chance bekommt man nicht so oft.

https://learngerman.dw.com/de/schwein-haben/l-19120315/lm