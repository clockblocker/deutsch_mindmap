[[0-root-da-sagt-mann-so|Back to list]]

---
---

Die halbe Miete sein.md#^1|^ Kein Vermieter der Welt würde sich einfach so mit der halben Miete zufriedengeben. Aber es gibt Situationen im Leben, da sollte man sich freuen, dass man immerhin die halbe Miete zusammenbekommen hat. ^1

Die halbe Miete sein.md#^2|^ Anja und Fatima arbeiten schon lange zusammen. Mittlerweile sind sie sogar Freundinnen und erzählen sich alles. ^2

Die halbe Miete sein.md#^3|^ Seit einiger Zeit ist Anja ein wenig nachdenklich. Daher ansprechen|spricht Fatima ihre Freundin in der Mittagspause darauf an. ^3

Die halbe Miete sein.md#^4|^ „Du, ich hab das Gefühl, dass dich etwas bedrückt. Magst du mir von deinen Sorgen erzählen?“ „Ja, du hast recht“, sagt Anja, ^4

Die halbe Miete sein.md#^5|^ „es gibt momentan so viele Dinge, die ich erledigen muss. Mein größtes Problem ist, dass ich für meine kleine Tochter einen Platz in einer Kindertagesstätte suche. ^5

Aber die Suche ist wirklich schwierig. Es gibt einfach keine freien Plätze in den Kitas in unserer Nähe …“

Die halbe Miete sein.md#^6|^ Fatima nickt mitfühlend. „Ich kenne das Problem“, sagt sie zu Anja. „Du weißt ja, dass ich auch lange einen Kitaplatz für meinen Sohn gesucht habe. ^6

Die halbe Miete sein.md#^7|^ Aber vielleicht könnte ich dir helfen. Ich kenne nämlich die Leiterin einer Kindertagesstätte ganz in deiner Nähe.“ ^7

„Und du meinst, du könntest mit der Leiterin reden?“ 

„Na klar“, sagt Fatima, „ich kenne sie wirklich ganz gut.“ „Das ist ja schon mal die halbe Miete“, sagt Anja hoffnungsvoll, „wenn du mir da helfen könntest, wäre ich dir sehr dankbar.“

 https://learngerman.dw.com/de/die-halbe-miete-sein/l-19121900/lm