[[0-root-da-sagt-mann-so|Back to list]]

---
---

https://learngerman.dw.com/de/sich-freuen-wie-ein-schneek%C3%B6nig/l-35946701/lm
**Sich freuen wie ein Schneekönig  
  
Es gibt viele Arten, sich zu freuen. Man kann laut lachen oder schreien. Man kann hüpfen oder rennen. Und manche Menschen hören sich dabei fast so an wie ein Vogel – wie der Zaunkönig, der auch Schneekönig genannt wird.**  
  
Moritz ist glücklich. Er fühlt sich richtig gut. Er springt auf dem Weg nach Hause vor Freude in die Höhe und singt dabei laut. 

Sein Nachbar hört ihn schon von Weitem. Er sieht Moritz’ breites Lächeln und wie er immer wieder in die Luft springt. 

„Na, du freust dich ja wie ein Schneekönig. Was ist denn passiert?“, fragt der Nachbar. 
Moritz lacht laut. „Ich habe Vanessa einen Heiratsantrag gemacht. Und sie hat Ja gesagt“, ruft Moritz glücklich. 
„Das ist ja toll!“, sagt der Nachbar, „herzlichen Glückwunsch.“ 

„Und das ist noch gar nicht alles“, ruft Moritz fröhlich, „ich habe auch noch im Lotto gewonnen – fast ein halbe Million Euro. Ist das nicht toll?“ 
Der Nachbar kann es kaum glauben. „Das gibt es nur selten. Glück im Spiel und in der Liebe haben nur wenige“, sagt er.

