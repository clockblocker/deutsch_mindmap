[[0-root-da-sagt-mann-so|Back to list]]

---
---

Wer kennt das nicht: Man hat zugenommen und muss den Gürtel ganz weit machen. Um den Gürtel enger schnallen zu können, muss man weniger essen. Bei einer deutschen Redensart muss man aber noch auf viel mehr verzichten.
  
Björn sitzt vor seinem Schreibtisch. Dort liegen viele Rechnungen. Sein Geschäft laufen|läuft zurzeit nicht gut und sein Konto ist fast leer. Er weiß nicht, wie er die nächsten Monate überstehen soll. 

Sein Freund hat ihm gesagt, dass er den Gürtel eben enger schnallen müsste. Zuerst will Björn das nicht glauben. 

Aber dann sieht er sich seine Kontoauszüge genauer an: 100 Euro für Bücher, 50 Euro fürs Kino, und allein 300 Euro hat Björn für Wein bezahlt. Er bekommt sechs Zeitschriften, die 80 Euro im Monat kosten. Und er zahlt 60 Euro im Monat für ein Fitnessstudio, in das er zu selten geht. 

„Ich gebe echt viel Geld aus“, stellt Björn staunend fest. Aber das sind auch alles Dinge, die ihn glücklich machen. Und auf die soll er in Zukunft verzichten?

„Das muss ich wohl“, denkt Björn, „ich muss tatsächlich den Gürtel enger schnallen.“ 

Er abbestellen|bestellt sofort die Zeitschriften ab und kündigt das Fitnessstudio. 

Er vornehmen|nimmt sich vor, in nächster Zeit nicht ins Kino zu gehen und weniger Wein zu trinken. Dann wird er es schon irgendwie schaffen.

https://learngerman.dw.com/de/den-g%C3%BCrtel-enger-schnallen/l-19536479/lm

👖🤏 den Gürtel enger schnallen *Redewendung*