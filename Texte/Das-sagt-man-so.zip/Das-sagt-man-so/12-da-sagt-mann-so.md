[[0-root-da-sagt-mann-so|Back to list]]

---
---

Ein Auge zudrücken

Wenn man seine Ruhe haben will, hilft es manchmal, die Augen zu schließen und an etwas Schönes zu denken. Ein Auge zudrücken.md#^1|^ Aber was bedeutet es, wenn man nur ein Auge schließt bzw. zudrückt? ^1

Es gibt Situationen, da möchte man lieber wegschauen oder so tun, als hätte man nichts gesehen. 

Aber manchmal geht es nicht anders. Wie im Fall von Irene, die als Managerin in einem noblen Restaurant arbeitet.

Ein Auge zudrücken.md#^2|^ Der neue Kellner Roman ist ziemlich tollpatschig. Immer wieder fällt ihm etwas aus der Hand oder er gießt den Wein daneben. ^2

Ein Auge zudrücken.md#^3|^ Das nervt ein bisschen. Aber Irene – und die Gäste übrigens auch – können Roman nicht so richtig böse sein und zudrücken|drücken immer wieder ein Auge zudrücken|zu. ^3

Ein Auge zudrücken.md#^4|^ Denn Roman ist der charmanteste Mensch der Welt. Hat er mal wieder den Wein danebengegossen, entschuldigt er sich so nett beim Gast, dass dieser ihm sofort verzeiht. ^4

Ein Auge zudrücken.md#^5|^ Und fällt ihm in der Küche ein Teller aus der Hand, so fegt er sofort die Scherben auf und macht alles wieder sauber. ^5

Ein Auge zudrücken.md#^6|^ Selbst der Chefkoch konnte sich vor ein paar Tagen nicht so richtig aufregen, obwohl Roman versehentlich Zucker in die Suppe getan hatte. ^6

Ein Auge zudrücken.md#^7|^ „Wollen wir mal nicht so sein!“, sagte er zu Roman, der sich reumütig entschuldigte. „Ich will mal ein Auge zudrücken!“ ^7


https://learngerman.dw.com/de/ein-auge-zudruecken/l-19055592/lm