[[0-root-da-sagt-mann-so|Back to list]]

---
---

Auf Bäumen sitzt man nicht besonders bequem. Manchmal gibt es aber Menschen, die so nervig sind, dass man am liebsten auf einen Baum klettern möchte. Dafür scheint ein bestimmter Baum besonders geeignet zu sein
  
Paul weiß immer alles besser: „Linda, nimm nicht so viel Kaffeepulver 1 für die Kaffeemaschine, sonst schmeckt der Kaffee wieder bitter“, sagt er, „Italiener nehmen immer nur vier Löffel Kaffee pro Person, so kommt das Aroma besser zur Geltung.“ 

Linda ist gerade aufgestanden und hat keine Lust, sich einen Kaffee-Vortrag anzuhören 1. Sie ignoriert ihren Mitbewohner und vorbereitet|bereitet weiter ihr Frühstück vor. 

„Du solltest das Brot in dünnere Scheiben schneiden, sonst bleibt es im Toaster stecken“, bemerkt Paul. Linda beißt die Zähne zusammen. 

„Weißt du, wie viel Zucker in dieser Marmelade steckt? Das ist ungesund!“, hört sie Paul sagen. Linda nimmt einen Extralöffel von der Marmelade. 

Paul wirft einen Blick auf Lindas Schuhe: „Hast du die Wettervorhersage für heute nicht gehört? Es soll regnen!“ „Ich habe aber gerne nasse Füße“, erwidert Linda nun offensichtlich genervt.  

„Was ist mir dir los, Linda, hast du schlecht geschlafen?“, fragt Paul. „Nein. Ich habe hervorragend geschlafen. Nur du bringst mich mit deiner Besserwisserei auf die Palme

Bevor Paul etwas sagen kann, hat Linda die Haustür mit einem großen Knall hinter sich zugeworfen.

 https://learngerman.dw.com/de/jemanden-auf-die-palme-bringen/l-18745538/lm