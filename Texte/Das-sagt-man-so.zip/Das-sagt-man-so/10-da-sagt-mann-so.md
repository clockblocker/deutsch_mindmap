[[0-root-da-sagt-mann-so|Back to list]]

---
---

Probleme gibt es im Leben genug. Ständig bekommt man neue Aufgaben, die man erfolgreich lösen muss. Doch es gibt manche Herausforderung, die so groß sind, dass man daraus ein Sprichwort machen muss.

Die Lehrerin Frau Schulte trifft sich mit Martins Eltern zu einem Gespräch. 

„Es gibt ein Problem mit Martin“, sagt Frau Schulte, „er ist seit dem ersten Schultag mit einem Mitschüler verfeindet. Fast jeden Morgen beschimpfen und prügeln sie sich. Und ansonsten reden sie überhaupt nicht miteinander. Das stört die Atmosphäre in unserer Klasse!“

Martins Eltern sind entsetzt. „Das kann ich gar nicht glauben, Martin ist doch so ein lieber Junge“, ruft der Vater. 

Frau Schulte sagt: „So kann es auf jeden Fall nicht weitergehen. Auch die Mitschüler leiden unter den ständigen Aggressionen. Also, wie holen wir die Kuh vom Eis?“ 

Der Vater weiß keine Lösung für das Problem. Martins Mutter schlägt vor: „Wir reden mit den Eltern des anderen Schülers. Vielleicht können wir ja zusammen mit den Kindern ein Eis essen gehen, und die beiden Jungen vertragen sich.“ 

Die Lehrerin nickt. „Eine gute Idee. Aber das wird nicht einfach und könnte für alle schnell peinlich werden.“ Doch Martins Mutter ist sich sicher, dass sie das schafft.


https://learngerman.dw.com/de/die-kuh-vom-eis-holen/l-19264750/lm