[[0-root-da-sagt-mann-so|Back to list]]

---
---

https://learngerman.dw.com/de/%C3%BCber-den-tellerrand-schauen/l-19264871/lm

**Über den Tellerrand schauen  
  
Die meisten Menschen wohlfühlen|fühlen sich dort wohl, wo sie sich auskennen. Doch wer über den Tellerrand schaut, kann viel entdecken: Einen Becher und Besteck findet man dabei eher nicht, aber ganz bestimmt neue Perspektiven.  

Mona hat gerade ihr Abitur gemacht. Die große Frage lautet: Was macht sie nun? 
„Du solltest mal über den Tellerrand schauen. Am besten gehst du für eine Weile ins Ausland“, meint ihr Vater. 
„Du könntest als Au-pair in Frankreich arbeiten und dein Französisch verbessern“, sagt ihre Mutter. 
„Bewirb dich um einen Studienplatz in Kanada!“, rät ihr Bruder. 
„Lass uns zusammen eine Weltreise machen“, vorschlagen|schlägt ihre beste Freundin vor. Aber Mona hat das Gefühl, dass das alles nicht das Richtige ist. 

Dann sieht sie zufällig eine Dokumentation über ein Umweltprojekt in Norddeutschland. Und sie weiß sofort: Dabei will sie mitmachen! „Was?“, fragt ihr Bruder. „Du könntest eine Weltreise machen und gehst nach … Norddeutschland? Im Ernst?“ 

Mona lächelt: „Ja, im Ernst. Da mache ich etwas Sinnvolles. außerdem habe ich mich bisher viel zu wenig mit Naturschutz beschäftigt. Ich werde bestimmt viel Neues lernen. Man muss nicht unbedingt um die halbe Welt reisen, um über den Tellerrand zu schauen, Brüderchen!“