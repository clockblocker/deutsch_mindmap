[[0-root-da-sagt-mann-so|Back to list]]

---
---

 https://learngerman.dw.com/de/etwas-durch-die-blume-sagen/l-18745487/lm