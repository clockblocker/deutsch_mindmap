[[0-root-da-sagt-mann-so|Back to list]]

---
---

Es gibt Menschen, die immer bekommen, was sie wollen, ganz ohne Druck oder Gewalt. Sie haben ein ganz besonderes Talent, andere zu manipulieren, ohne dass diese es wirklich merken. Aber wie machen sie das?  
  
„Sie wickelt dich immer um den Finger“, sagt Peter. Sein bester Freund Leo sitzt ihm gegenüber und fragt erstaunt: „Wie meinst du das?“ 

Peter erinnert ihn an das Fußballturnier letzten Sommer. Leo hat nicht mitspielen können, weil seine Freundin unbedingt dieses Wochenende am Strand verbringen wollte. 

„Sie war von der Arbeit so gestresst …“, versucht Leo zu erklären. „Und was ist mit Jörgs Geburtstag? Da warst du auch nicht dabei“, kontert Peter. 

„Ja, da hatte gerade das neue Restaurant aufgemacht, und sie wollte es unbedingt ausprobieren“, redet sich Leo wieder raus. 

„Früher haben wir uns jeden Donnerstag zu einem Feierabendbier getroffen …“, bemerkt Peter. „Aber Donnerstag ist unser Kinoabend …“, erwidert Leo. 

„Und die Weihnachtsfeier?“, möchte Peter wissen. „Wir gehen zu einem Konzert. Sie hat Karten organisiert, und das war ganz schön schwer. Und sie freut sich so sehr darauf!“, erzählt Leo.

„Sag ich doch“, sagt Peter. „Sie wickelt dich immer um den Finger, und du merkst es einfach nicht.“ Leo zuckt mit den Schultern. Er denkt an das zufriedene Lächeln seiner Freundin und den Glanz in ihren schönen Augen, als er ihr versprochen hat, mit ihr zu dem Konzert zu gehen. 

„Du bist der Beste!“, hatte sie gesagt. Dieser Satz ist für ihn schöner als jede Weihnachtsfeier.


https://learngerman.dw.com/de/jemanden-um-den-finger-wickeln/l-18745495/lm