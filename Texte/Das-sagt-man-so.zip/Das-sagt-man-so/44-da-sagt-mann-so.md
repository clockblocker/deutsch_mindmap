[[0-root-da-sagt-mann-so|Back to list]]

---
---

Nur wenigen gelingt es, sich von ihrem eigenen Schatten zu lösen: Lucky Luke zum Beispiel schießt schneller als er und Peter Pan sucht ihn. Aber wie schafft man es, über seinen eigenen Schatten zu springen?

Gleich ist es 20 Uhr. Der Theatersaal ist voll, das Stück ist ausverkauft. 

Jonas hat gleich seinen ersten Auftritt. Sie spielen „Wilhelm Tell“, und Jonas hat die Hauptrolle.

Dabei stand er noch nie auf einer Bühne. Er hat sich bisher nie getraut, als Schauspieler im Theater aufzutreten, weil er immer so schrecklich aufgeregt ist. 
 
Er ist sogar aufgeregt, wenn er an Weihnachten seinen Großeltern ein Gedicht aufsagt. Und jetzt soll er vor hunderten fremden Leuten eine Stunde lang auf der Bühne stehen? 
 
Jonas wischt sich den Schweiß von der Stirn. Er zittert am ganzen Körper. Seine Schauspielkollegin Lisa kommt zu ihm. 
 
 „Ist alles in Ordnung?“, fragt sie. 
 „Nein“, sagt Jonas sichtlich nervös, „ich kann das nicht. Ich gehe nach Hause. Ich bin einfach zu aufgeregt. Schauspielen ist nicht das Richtige für mich.“ 
 
 Lisa schüttelt den Kopf: „Das ist doch Quatsch. Du kannst das, du musst nur endlich mal über deinen eigenen Schatten springen!“ Jonas nickt. Lisa hat recht. Er muss sich endlich einmal überwinden. 
 
 Jonas durchatmen|atmet tief durch. Dann geht er entschlossen auf die Bühne. Jetzt muss er für eine Stunde ein Held sein – eine Stunde lang Wilhelm Tell sein!
 
 https://learngerman.dw.com/de/ueber-den-eigenen-schatten-springen/l-19264879/lm