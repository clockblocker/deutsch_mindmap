[[0-root-da-sagt-mann-so|Back to list]]

---
---

Ein Haar in der Suppe? Das möchte doch niemand haben. Aber es gibt tatsächlich Menschen, die extra danach suchen. Und sie freuen sich, wenn sie ein Haar in der Suppe gefunden haben. Aber warum ist das so?
  
Elena ist sauer. Sechs Monate lang hat sie an einem wichtigen Projekt gearbeitet. Ihr Abschlussbericht war perfekt. ausführlich, detailliert, sachlich. 

„Ich habe alles reingeschrieben, was sie wissen soll!“, sagt Elena beleidigt. Mit „sie“ ist ihre Chefin gemeint, die schwer zufriedenzustellen ist. 

Oder wie es Elena ausdrücken würde: „Man kann es ihr nie recht machen!“ Elenas Chefin sucht gerne das Haar in der Suppe. Das heißt natürlich nicht, dass sie jeden Suppenteller nach Haaren durchsucht, sondern dass sie oft das Schlechte hervorhebt und dabei viel Gutes übersieht. 

Diesmal gefiel ihr die Nummerierung der Seiten in Elenas Bericht nicht. „Die Seitenzahlen sollten immer unten rechts stehen. Bitte achten Sie in Zukunft darauf!“, war ihr einziger Kommentar zu dem Bericht. 

Elenas Freundin Susanne versucht, sie zu trösten: „Ärgere dich nicht! Deine Chefin sucht doch immer ein Haar in der Suppe. Sie ist eben besonders kritisch, aber das hat nichts mit dir zu tun. Ich bin mir sicher: Sie weiß genau, wie gut du arbeitest!“

 https://learngerman.dw.com/de/das-haar-in-der-suppe-suchen/l-18745493/lm
 
🔎😠 das Haar in der Suppe suchen *Redewendung*
🧊🤝 das Eis brechen *Redewendung*
🐛🚫 da ist der Wurm drin *Redewendung*
🎩🧩🤹‍♂️ alles unter einen Hut bringen *Redewendung*
👖🤏 den Gürtel enger schnallen *Redewendung*
☁️7️⃣🥰 auf Wolke sieben schweben *Redewendung*