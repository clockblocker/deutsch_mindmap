[[0-root-da-sagt-mann-so|Back to list]]

---
---

Normalerweise verbindet man das Herz mit Liebe und Romantik. Man kann zum Beispiel sein Herz an jemanden verlieren oder jemandem das Herz brechen. Aber was bedeutet es, wenn einem das Herz in die Hose rutscht?

Fred ist ein Abenteurer. Er geht gerne in fremden Ländern auf Reisen und er liebt Ziele fernab der großen Touristenmagnete. Er ist mutig und hat weder Angst vor giftigen Spinnen noch steilen Abhängen.

Dieses Jahr flog Fred nach Namibia, um sich endlich einen großen Wunsch zu erfüllen: exotische Tiere in freier Wildbahn beobachten. Und tatsächlich wurden seine Erwartungen erfüllt. In den weiten Landschaften Namibias konnte Fred Zebras, Giraffen und Elefanten aus nächster Nähe bewundern.

Mit seiner Kamera machte Fred Fotos für seine Freunde zu Hause. Aber dann passierte etwas, womit er nicht gerechnet hatte: Fred war gerade damit beschäftigt, eine Gruppe Giraffen zu fotografieren, als er hinter sich ein Geräusch hörte. Er drehte sich langsam um und stand einem riesigen Löwen gegenüber!

„Zum ersten Mal in meinem Leben“, erzählte er später seinen Freunden zu Hause, „dachte ich, dass ich nicht lebend nach Hause komme. Mir ist das Herz in die Hose gerutscht.“

Zum Glück behielt Fred in dieser Situation doch noch einen kühlen Kopf. Er blieb ruhig stehen und Tat einfach nichts.

Der Löwe schaute ihn eine Zeit lang an und machte sich dann auf den Weg zu den Giraffen. Glück gehabt! Nächstes Jahr möchte Fred unbedingt nach London. Den Buckingham Palace wollte er schon immer sehen …

https://learngerman.dw.com/de/jemandem-rutscht-das-herz-in-die-hose/l-19068103/lm
