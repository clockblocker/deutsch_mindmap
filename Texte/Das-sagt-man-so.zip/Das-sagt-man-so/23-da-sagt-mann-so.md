[[0-root-da-sagt-mann-so|Back to list]]

---
---

 https://learngerman.dw.com/de/geld-zum-fenster-hinauswerfen/l-18745507/lm
 Geld zum Fenster hinauswerfen