[[0-root-da-sagt-mann-so|Back to list]]

---
---

https://learngerman.dw.com/de/ein-tropfen-auf-den-hei%C3%9Fen-stein/l-19267509/lm

**Ein Tropfen auf den heißen Stein  
  
Was nützt es, wenn man einen Tropfen Wasser auf einen heißen Stein fallen lässt? Nicht viel. Der Tropfen verdampft sofort. Um einen messbaren Effekt zu erzielen, braucht es schon deutlich mehr.
  
Als Martin von der Uni nach Hause kommt, sitzt sein Mitbewohner Tom mit einer Tüte Chips auf dem Sofa. Genau auf dem Sofa, auf dem Martins Mutter morgen übernachten soll, wenn sie zu Besuch kommt. Um das Sofa herum stapeln sich alte Zeitungen, ungebügelte Wäsche und leere Getränkekisten. 

Auf der Fensterbank stehen die Pflanzen, die Martin und Tom vor einiger Zeit gekauft haben, um die Wohnung schöner zu machen. Leider haben sie vergessen, sie zu gießen. 

Die braunen Blätter der Pflanzen liegen schon seit Wochen auf dem Boden. Martin ist sauer: „Mann, du wolltest doch aufräumen! Du das Wohnzimmer, ich die Küche – das war die Vereinbarung.“ 

Tom ist beleidigt: „Moment mal, ich habe das ganze Geschirr in die Küche gestellt.“ 
Martin schaut in die Küche. Tatsächlich: Die ganze Spüle ist voller Teller, Gläser und Tassen – immer noch schmutzig natürlich. 

„außerdem“, erklärt Tom, „habe ich die Bücher ins Regal geräumt.“ 
Martin schimpft: „Die paar Bücher? Das war doch nur ein Tropfen auf den heißen Stein! Was ist mit der Wäsche, den Getränkekisten, den Pflanzen?“ 

Tom seufzt: „Okay, okay, die Chipstüte ist sowieso leer.“ 
„Na, bestens“, sagt Martin, „dann kannst du sie gleich in die Mülltonne werfen. Und nimm die alten Zeitungen mit!“