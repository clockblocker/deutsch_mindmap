[[0-root-da-sagt-mann-so|Back to list]]

---
---

Eine Extrawurst bekommen  

Eine Extrawurst bekommen.md#^1|^ Die Deutschen sind ein Volk von Wurstessern. Und zwar so sehr, dass sich hier sogar Vegetarier über eine Wurst freuen können – zumindest, wenn es sich redensartlich um eine Extrawurst handelt. ^1

Eine Extrawurst bekommen.md#^2|^ Tim ist ein guter Fußballspieler – finden seine Eltern. Sie sind davon überzeugt, dass er später einmal Profi werden kann. ^2

Eine Extrawurst bekommen.md#^3|^ Deswegen fahren sie ihn viermal die Woche zum Training und erlauben ihm, jede freie Minute mit seinen Freunden Fußball zu spielen. ^3

Letzte Woche musste Tim nicht mal seine Hausaufgaben zu Ende machen: Seine Eltern haben der Schule einfach eine Entschuldigung geschrieben.

Eine Extrawurst bekommen.md#^4|^ Tims Schwestern Hannah und Lara ärgern sich schon lange darüber, dass ihr Bruder ständig bevorzugt wird. ^4

Eine Extrawurst bekommen.md#^5|^ Aber heute sind sie so richtig wütend: Beim Abendessen haben ihnen die Eltern gerade erzählt, dass sie nächstes Wochenende alle zu Tante Gisela fahren werden. ^5

Eine Extrawurst bekommen.md#^6|^ ausgerechnet zu Tante Gisela, die Kinder doch sowieso nicht leiden kann! Das Schlimmste aber ist: Tim muss nicht mitkommen. ^6

Er darf zu seinem Freund Carl, um für das nächste Spiel zu trainieren. 

Eine Extrawurst bekommen.md#^7|^ Hannah und Lara aufspringen|springen auf: „Das ist unfair!“, rufen sie fast gleichzeitig. ^7

Eine Extrawurst bekommen.md#^8|^ „Tim bekommt immer eine Extrawurst!“ Ihre Eltern gucken erstaunt. ^8

Eine Extrawurst bekommen.md#^9|^ „Wieso? Ihr mögt doch Fußball gar nicht“, sagt die Mutter. Die Mädchen stöhnen. Nichts hat die Mutter verstanden, gar nichts! ^9

https://learngerman.dw.com/de/eine-extrawurst-bekommen/l-19335355/lm

