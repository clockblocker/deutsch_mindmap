[[0-root-da-sagt-mann-so|Back to list]]

---
---

Der Angestellte vom Chef, das Kind von seinen Eltern, der Schüler vom Lehrer – sie alle können schon mal eins auf den Hut, also den Deckel bekommen. Zwar nicht im wörtlichen Sinne, aber unangenehm ist es trotzdem.**  
  
Finja weiß genau, was sie später einmal werden will: Profifußballerin. Deswegen übt sie jeden Tag mit ihrem Freund Kilian, der genauso fußballbegeistert ist wie sie. Meistens gehen sie auf den Sportplatz, aber heute üben sie im Garten und schießen Bälle gegen die Garage. Eigentlich sollen sie das nicht machen, aber Finja hatte keine Lust, zum Sportplatz zu laufen, und ihre Mutter ist nicht da. Finja hat gerade einen tollen Treffer erzielt, als ihre Mutter um die Ecke biegt. „Finja! Komm sofort her!“, ruft sie. Finja geht mit ihrer Mutter ins Haus. Nach einer Viertelstunde kommt sie wieder heraus. „Hast du eins auf den Deckel bekommen?“, fragt Kilian. Finja nickt. „Sie war ziemlich sauer. Am Wochenende werde ich wohl keine Zeit zum Fußballspielen haben. Da muss ich meinen Eltern helfen, die Garage neu zu streichen“, sagt sie. Kilian grinst. Da sind wirklich ziemlich viele runde Flecken an der Garagenwand. Dann hat er eine Idee: „Weißt du was? Ich komme vorbei und helfe dir. Dann geht es schneller. Und danach spielen wir zusammen Fußball. Aber dann gehen wir doch lieber auf den Sportplatz.“

<iframe src="https://learngerman.dw.com/de/eins-auf-den-deckel-bekommen/l-19536491/lm" allow="fullscreen" allowfullscreen="" style="height:50%;width:100%; aspect-ratio: 16 / 9; "></iframe>


1 rechnen  	etwas nach den Regeln der Mathematik lösen
2 rechnen mit 	das Eintreten von etwas als ziemlich sicher ansehen
3 rechnen 	etwas ermitteln
4 rechnen unter/zu 	etwas als zu etwas gehörig betrachten
5 rechnen in 	etwas in etwas umrechnen
6 rechnen als 	etwas als ein solches bewerten
7 rechnen auf 	sich auf etwas verlassen
8 rechnen zu 	zu etwas gehören
9 rechnen auf/für/pro 	für etwas irgendwieviel veranschlagen
10 rechnen als 	als ein solches bewertet werden

1.  rechnen: to solve something according to the rules of mathematics
2.  rechnen mit: to consider the occurrence of something as quite certain
3.  rechnen: to determine something
4.  rechnen unter/zu: to consider something as belonging to something
5.  rechnen in: to convert something into something
6.  rechnen als: to evaluate something as such
7.  rechnen auf: to rely on something
8.  rechnen zu: to belong to something
9.  rechnen auf/für/pro: to estimate something at a certain amount
10. rechnen als: to be evaluated as such

