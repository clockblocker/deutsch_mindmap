[[0-root-da-sagt-mann-so|Back to list]]

---
---

чOb Bratwurst, Weißwurst oder Frikadelle: Manche Speisen schmecken mit Senf einfach besser. Aber man kann Senf auch in einer Diskussion oder bei einem Streit einsetzen. Und darüber freuen sich die wenigsten.

Eigentlich wollen Tanja, Hans und Carmen einen netten Nachmittag bei Kaffee und Kuchen verbringen, aber es kommt anders: Tanja und ihr Freund Hans anfangen|fangen mal wieder einen Streit an. 

Hans findet es doof, dass Tanja die meiste Zeit am Computer verbringt, während er sich um den Haushalt kümmern muss.

 „Also, wenn ich nicht putzen würde, würden wir im Dreck untergehen!“, sagt Hans. „Das stimmt doch gar nicht“, erwidert Tanja. 
 
 „Ich putze doch! Wenn deine Freunde nicht dauernd Dreck machen würden, hätten wir das Problem nicht.“ 
 
 Während die zwei streiten, sitzt Carmen daneben und versucht, ruhig zu bleiben. 
 
 Als die beiden nach zehn Minuten immer noch streiten, verliert sie die Geduld: 
 „Also, ich möchte mich ja nicht einmischen …“, sagt sie, „aber wie wäre es, wenn ihr einen Putzplan aufstellt? Würde das die Sache nicht einfacher machen?“ 
 
 Tanja und Hans schauen sie genervt an. „Musst du wirklich immer zu allem deinen Senf dazugeben“, sagt Tanja, „das angehen|geht dich nun wirklich nichts an!“

https://learngerman.dw.com/de/seinen-senf-dazugeben/l-19120337/lm