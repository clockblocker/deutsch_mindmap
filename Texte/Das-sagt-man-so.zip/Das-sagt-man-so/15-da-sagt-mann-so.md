[[0-root-da-sagt-mann-so|Back to list]]

---
---

https://learngerman.dw.com/de/eine-doktorarbeit-aus-etwas-machen/l-19536485/lm
**Eine Doktorarbeit aus etwas machen** 
  
Es gibt Mensch|Menschen, bei denen selbst kleine arbeit 1|Arbeiten endlos dauern.
Sie denken|denken über jede Kleinigkeit lange nachdenken|nach, entscheiden sich oft umentscheiden|um und beginnen|beginnen wieder von vorn. Für andere kann das ziemlich nervig sein.
  
Werner hat beim aufräumen ein altes Urlaubsfoto gefunden. Er hat einen Rahmen dafür gekauft und will es im Wohnzimmer aufhängen.
Jetzt überlegt er: Soll er das Bild neben das Regal hängen oder über das Sofa? Oder an die Wand gegenüber vom Fenster?  Nein, doch über das Sofa. Noch ein bisschen weiter links vielleicht … 
Endlich hängt das Bild an der Wand. Aber ist das Wohnzimmer überhaupt der richtige Platz dafür? Passt das Bild zur Farbe des Sofas? Werner ist sich nicht sicher. 

„Katrin“, wendet er sich an seine Frau, „soll ich das Bild nicht besser ins Schlafzimmer hängen?“ 
Katrin schaut kurz zur Wand. „Also, ich finde, dass es gut ins Wohnzimmer passt.“
"In Ordnung", denkt Werner. Aber vielleicht würde das Bild ohne Rahmen besser wirken. „Katrin, meinst du nicht, dass der Rahmen zu dunkel ist?“ 
Katrin seufzt. „Werner, jetzt mach doch keine Doktorarbeit daraus. Das Foto ist sehr schön, und wir werden uns immer gerne an diesen Urlaub erinnern, egal, wie der Rahmen aussieht.“ 

Das sieht Werner anders. Er wird noch einmal losfahren und einen anderen Rahmen kaufen. 

Katrin weiß: Das kann einige Zeit dauern. Na gut, dann kann sie jetzt erst mal in Ruhe einen Kaffee trinken.
