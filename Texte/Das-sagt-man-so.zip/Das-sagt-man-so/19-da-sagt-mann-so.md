[[0-root-da-sagt-mann-so|Back to list]]

---
---

<iframe src="https://learngerman.dw.com/de/einen-ohrwurm-haben/l-19264883/lm" allow="fullscreen" allowfullscreen="" style="height:100%;width:100%; aspect-ratio: 16 / 9; "></iframe>

Einen Ohrwurm haben? Das klingt nach einer ganz fiesen Krankheit.
Doch ein Ohrwurm ist zum Glück kein Tier, das einem im Ohr herumkriecht, sondern ein Lied
Das ist zwar nicht gefährlich, kann aber ziemlich nervig sein.
Thomas lässt sich gerne von Musik wecken.
Am liebsten hört er Pop-Musik aus den 60ern und 70er.
Deshalb hat er auch einen Oldie-Sender auf seinem Radio-Wecker eingestellt.
Heute Morgen spielt er „Yellow Submarine“ von den Beatles.
Gut gelaunt steht Thomas auf und summt die Melodie mit.
Unter der Dusche pfeift er sie.
Auf dem Weg zur Arbeit singt er sie.
Und auch als er im Büro sitzt, hat er die Musik noch im Kopf.
Er kann sich gar nicht auf die Arbeit konzentrieren.
„Ich habe schon den ganzen Morgen einen Ohrwurm“, sagt er zu seinem Kollegen.
„Ich weiß.
Du summst ja die ganze Zeit dieses Lied.
Deinetwegen habe ich jetzt auch einen“, antwortet der Kollege.
Thomas will, dass der Ohrwurm verschwindet.
Er singt einen anderen Song, „Dancing Queen“ von ABBA.
Vielleicht hilft das.
Und tatsächlich: An „Yellow Submarine“ denkt Thomas nicht mehr.
Dafür hat er jetzt einen anderen Ohrwurm.
Aber als Thomas abends nach Hause kommt, sind die Beatles wieder da.
Im Bett greift er zum Wecker und ändert den Sender.
Er will nicht schon wieder den ganzen Tag lang einen Ohrwurm haben.
Thomas liegt im Bett und kann nicht schlafen.
Er pfeift immer noch „Yellow Submarine“… Verdammter Ohrwurm!
