[[0-root-da-sagt-mann-so|Back to list]]

---
---

**Mit den Wölfen heulen  
  
Wer anders ist als die anderen, eine andere Meinung hat oder auch nur einen anderen Geschmack, hat es oft schwer.
Da ist es leichter, mit den Wölfen zu heulen – selbst dann, wenn man Wolfsgeheul eigentlich nicht mag.

Freddie und Amelie haben sich ein Haus gekauft – in einer ruhigen Wohngegend mit weiß gestrichenen Häusern und gepflegten Gärten. 

Ihre Freundin Natalja hatte so ihre Zweifel, ob die beiden sich dort wohlfühlen würden, denn bei Freddie und Amelie war es immer bunt und laut und ziemlich unordentlich. 

Ob sie mit den Nachbarn zurechtkommen werden, die offenbar viel Wert auf Ruhe und Ordnung legen? 

Als sie ihre Freunde zum ersten Mal besucht, staunt sie nicht schlecht: keine laute Musik, die aus offenen Fenstern schallt, keine wild wachsende Blumenwiese vor dem Haus. 

Stattdessen ein ordentlich gemähter rasen und ein weißer Zaun. Da fehlen ja nur noch die Gartenzwerge! Ist sie hier wirklich bei Freddie und Amelie? 

Aber es ist tatsächlich Freddie, der die Tür öffnet und sie mit einem Lächeln begrüßt. 
„Ich dachte schon, ich hätte mir die falsche Hausnummer aufgeschrieben“, sagt Natalja. 
„Das ist doch gar nicht euer Stil.“ 
„Tja“, antwortet Freddie mit einem Schulterzucken, „wir wollen ja keinen Stress mit den Nachbarn. Wenn man hier wohnen will, muss man eben mit den Wölfen heulen.“ 

Schade, denkt Natalja. Freddies und Amelies chaotische Wohnung hat ihr irgendwie besser gefallen.

https://learngerman.dw.com/de/mit-den-w%C3%B6lfen-heulen/l-19368379/lm
