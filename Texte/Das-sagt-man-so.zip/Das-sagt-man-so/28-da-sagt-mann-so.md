[[0-root-da-sagt-mann-so|Back to list]]

---
---

Es gibt viele Arten, einander Glück zu wünschen. Man kann „viel Erfolg!“ sagen oder jemandem die Daumen drücken. Ob es hilft? Immerhin: Wer freut sich nicht darüber, dass an ihn gedacht wird?
  
Gloria hat morgen Führerscheinprüfung. Sie ist gut vorbereitet, hat aber dennoch Angst. 

Was ist, wenn der Prüfer einen schlechten Tag hat und sie mit schwierigen Aufgaben quält? Was ist, wenn es die ganze Zeit regnet und sie nichts sehen kann? Und was ist, wenn sie zu nervös ist, um richtig Worterzuparken? 

Zu ihrer Schwester Greta sagt sie: „Drück mir bitte die Daumen, dass alles gut geht!“ 

Greta versteht die Ängste ihrer Schwester gut. 
„Es bringt überhaupt nichts, nervös zu sein“, sagt sie. 
„Ich drücke dir die Daumen. Du schaffst das alles.“ 

Natürlich besteht Gloria die Führerscheinprüfung. Zu ihrer Schwester sagt sie: 

„Danke, dass du mir die Daumen gedrückt hast. Das hat mir wirklich geholfen!“

„Quatsch!“, sagt Greta, „Ich hab zwar fest an dich geglaubt, aber das hast du ganz allein geschafft!“

https://learngerman.dw.com/de/jemandem-die-daumen-druecken/l-19042072/lm