[[0-root-da-sagt-mann-so|Back to list]]

---
---

**Jemandem die Suppe versalzen  
  
Eine Suppe kann sehr lecker sein, besonders mit der richtigen Menge Salz. reintun|Tut man aber zu viel davon rein, ist sie nicht mehr genießbar. Wer würde sich nicht ärgern, wenn ihm jemand heimlich die Suppe versalzen würde?
  
Lena hat einen neuen Kollegen: Bastian. Ihr Chef ist begeistert von Bastians Qualifikationen: Studium an einer teuren Privatuniversität, Auslandserfahrung, sehr gute Englischkenntnisse.

Dass Bastian von der täglichen Arbeit in der Firma wenig weiß, sieht ihr Chef nicht. Lena dagegen merkt es schnell, denn sie arbeitet eng mit Bastian zusammen. 

Leider hat sie nicht den Eindruck, dass Bastian sich besonders anstrengt. Trotzdem will er unbedingt das neue Projekt leiten. 
 
 Er würde gern mehr Verantwortung übernehmen, hat er zum Chef gesagt. Lena ist klar, was das bedeutet: Sie wird die Arbeit machen und Bastian wird den Erfolg für sich verbuchen. 
 
Aber dem wird sie die Suppe schon noch versalzen! Beim nächsten Termin mit ihrem Chef macht sie einige Vorschläge für das Projekt. 
 
Und fragt dann ganz freundlich: „Bastian, wie ist denn deine Meinung dazu?“ 
Bastian zögert: „Ähm, also … ja, darüber muss ich mal nachdenken.“ 
 
 Als Lena abends nach Hause geht, hat sie die Projektleitung in der Tasche. Und Bastian? Der wird unter Lenas Leitung sicher wertvolle Erfahrungen sammeln, meint der Chef.

https://learngerman.dw.com/de/jemandem-die-suppe-versalzen/l-19368370/lm

















