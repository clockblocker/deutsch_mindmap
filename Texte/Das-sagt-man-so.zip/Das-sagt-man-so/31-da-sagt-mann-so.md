[[0-root-da-sagt-mann-so|Back to list]]

---
---

 Ein Loch im Bauch – da denkt man doch gleich an Mord und Totschlag. Zum Glück steckt meist etwas ganz Harmloses dahinter. Was aber nicht heißt, dass die betroffenen Menschen sich darüber freuen würden.

Kinder wollen alles wissen. Doch die kleine Anna ist etwas zu neugierig. Sie stellt ununterbrochen Fragen. 

„Mama, wo wohnt die Oma?“, fragt Anna. „In Köln“, antwortet die Mutter, die eigentlich versucht zu arbeiten. 

Aber Anna fragt weiter: „Wo liegt das?“ „In Nordrhein-Westfalen“, sagt die Mutter geduldig. 

„Ist das in der Nähe von Berlin?“ „Nein, Berlin liegt im Osten von Deutschland und Köln im Westen.“ 

Und die kleine Anna fragt immer weiter: „Warum wohnt die Oma in Köln?“ „Sie wurde dort geboren und lebt schon ihr ganzes Leben dort“, erklärt die Mutter schon leicht genervt. 

„Ja, aber warum wurde sie dort geboren?“, fragt Anna. „Weil die Eltern von deiner Oma auch in Köln gelebt haben“, sagt die Mutter. 

„Und warum haben sie nicht in Berlin gelebt?“, fragt Anna. Jetzt hat die Mutter genug. Sie kann sich bei der ganzen Fragerei gar nicht konzentrieren. 

„Hör auf, mir Löcher in den Bauch Jemandem Löcher in den Bauch fragen|zu fragen! Ich muss arbeiten“, sagt sie streng. „Warum stört dich das?“, fragt Anna, „was arbeitest du?“ Die Mutter seufzt. Die kleine Anna ist nicht zu stoppen. Sie ist einfach zu neugierig.


https://learngerman.dw.com/de/jemandem-loecher-in-den-bauch-fragen/l-19267503/lm