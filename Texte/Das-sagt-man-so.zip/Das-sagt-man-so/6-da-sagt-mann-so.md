[[0-root-da-sagt-mann-so|Back to list]]

---
---

Wer etwas verliert und es wiederhaben will, muss suchen – in dieser Ecke oder in jener. Den redensartlichen Faden findet man dort aber nicht. Dazu muss man schon in die Tiefe seines eigenen Geistes eindringen.
  
Julian arbeitet zwei Tage pro Woche im Homeoffice. Normalerweise klappt das problemlos, aber heute ist seine Tochter Maja erkältet und geht nicht in die Kita. Zum Glück hat er noch ein Malbuch gefunden, mit dem sie sich begeistert beschäftigt. So kann er seinem Team in Ruhe das neue Projekt vorstellen.

Julian spricht gerade über den vorläufigen Zeitplan und alle sind konzentriert bei der Sache. Plötzlich steht Maja neben ihm. Er hat sie gar nicht kommen hören. 

„Papa, guck mal, das ist eine Fee! Sie hat blaue Haare und grüne Augen.“ Seine Tochter hält ihm das Malbuch vor die Nase. Julian lächelt.

 Seiner Tochter scheint es wieder besser zu gehen. „Das ist wirklich eine sehr schöne Fee“, sagt er und Maja freut sich. 
 
 Dann wendet Julian sich wieder seinen Kolleginnen und Kollegen zu. Was wollte er gerade sagen? 
 
 „Entschuldigung, ich habe Den Faden verlieren|den Faden verloren.“ Ach ja, richtig, der Zeitplan.
 
  Also, bis Ende des Jahres könnten wir …“ „Papa, was bedeutet das: den Faden verlieren?“ Und schon hat er ihn wieder verloren, den Faden. 
  
  Die Kollegen lächeln. Sie kennen solche Situationen. Und Julian beschließt: Nach der Besprechung wird er eine längere Pause machen und ein bisschen mit Maja spielen.

https://learngerman.dw.com/de/den-faden-verlieren/l-19536507/lm


🧵😵‍💫 den Faden verlieren <span class="custom-wortart">Redewendung</span>
see