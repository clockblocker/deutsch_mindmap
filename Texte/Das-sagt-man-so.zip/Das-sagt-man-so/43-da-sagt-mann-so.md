[[0-root-da-sagt-mann-so|Back to list]]

---
---

Manche Menschen legen sich Gurken auf die Augen, um etwas für ihre Schönheit zu tun. Tomaten benutzt man dafür nicht. Trotzdem gibt es Leute, die Tomaten auf den Augen haben. Und das kann richtig gefährlich werden.
  
Carola ist auf dem Weg zur Uni. Um halb neun hat sie eine wichtige Prüfung, aber so richtig wach ist sie noch nicht.

Hoffentlich hilft ihr der Kaffee, den sie sich gerade im Café um die Ecke geholt hat. Sie hätte gestern früher ins Bett gehen sollen, fast hätte sie verschlafen. Zum Glück hat sie es nicht weit, nur zehn Minuten zu Fuß. Wie spät ist es eigentlich? 

Carola sucht mit einer Hand nach ihrem Handy, während sie in der anderen den vollen Kaffeebecher balanciert. Hat sie das Handy mitgenommen? Irgendwo muss es doch sein! 

Ohne auf ihre Umgebung zu achten, läuft sie weiter –, bis sie ein lautes Quietschen hört. Carola blickt hoch: Sie steht mitten auf der Straße, neben ihr hat ein Auto eine Vollbremsung gemacht. 

Die junge Frau am Steuer sieht erschrocken aus: „Sag mal, hast du Tomaten auf den Augen?“, ruft sie aus dem Fenster. „Ich hätte dich fast überfahren!“ 

„Entschuldigung!“, antwortet Carola. Sie muss wirklich besser aufpassen. Sonst klappt es heute bestimmt nicht mit der Prüfung.

 https://learngerman.dw.com/de/tomaten-auf-den-augen-haben/l-19267487/lm