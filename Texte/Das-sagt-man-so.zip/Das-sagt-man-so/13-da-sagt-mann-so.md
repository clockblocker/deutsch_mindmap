[[0-root-da-sagt-mann-so|Back to list]]

---
---

https://learngerman.dw.com/de/ein-dickes-fell-haben/l-19536473/lm

**Ein dickes Fell haben**

**Viele Tiere haben ein dickes Fell. Es hilft ihnen, starke Kälte und Wind zu ertragen. Auch manche Menschen müssen ein dickes Fell haben, um sich zu schützen. Und dafür brauchen sie nicht mal Haare.**

Tanja Schulz arbeitet seit ein paar Monaten als Lehrerin an einer Gesamtschule. Heute unterrichtet sie wieder die siebte Klasse in Mathematik. Laura ist seit ein paar Tagen sehr unkonzentriert, auffallen|fällt ihr auf.

Nach dem Unterricht ansprechen|spricht sie sie deshalb an. Laura anfangen|fängt an zu weinen: „Meine Eltern lassen sich scheiden!“
Oh je, denkt Tanja, das ist nicht leicht für das Mädchen. Leider kann sie nicht lange mit ihr sprechen, denn sie hat Aufsicht auf dem Pausenhof.

Dort ist es sehr laut, und immer wieder muss sie Streit schlichten. Und in Gedanken ist sie immer noch bei Laura.

Nach der Pause hat sie ein Elterngespräch. Da zugehen|geht es hoffentlich etwas ruhiger zu.
Aber im Gegenteil: Die Mutter von Marvin ist wütend: „Sie haben meinem Sohn eine Fünf gegeben! Bei seinem alten Lehrer hatte er immer gute C1 Schreiben/misc/Noten! Ganz bestimmt ist es Ihre Schuld, dass er plötzlich so schlecht ist!“
Tanja will den Eltern erklären, dass ihr Sohn nicht mehr lernt, seit er ständig mit seinen Freunden Party macht. Aber die zuhören|hören ihr gar nicht zu.

Eine halbe Stunde später sitzt sie müde im Lehrerzimmer. „Harter Tag?“, fragt ein Kollege. Tanja nickt nur.
„Irgendwann wird es besser“, verspricht er. „Du darfst dir nicht alles zu Herzen nehmen. Manchmal braucht man ein dickes Fell.“
Tanja seufzt: „Kann man sich dieses Fell irgendwo bestellen? Im Internet vielleicht?“
Der Kollege lacht: „Das Geld kannst du dir sparen. In unserem Job kriegst du das kostenlos. Leider dauert es ein paar Jahre.“
