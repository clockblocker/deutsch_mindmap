[[0-root-da-sagt-mann-so|Back to list]]

---
---

Auf Wolke sieben schweben
 
Manchmal fühlt sich das Leben einfach schön an.
Die Sonne scheint, die Vögel singen, der Himmel ist blau, alles ist perfekt.
Der Grund dafür ist meistens einfach: Man ist verliebt.
 
Manchmal ist das Leben einfach perfekt.
Neulich war Diana im Supermarkt.
Ein Mann kam auf sie zu und fragte: „Kannst du mir helfen? Was bedeutet ‚Sahne‘?“ Während Diana erklärt, was „Sahne“ ist, bemerkt sie, dass der Mann wunderschöne Augen hat.
„Ich bin aus Kanada“, sagt er.
„Kanada, mein Lieblingsland!“, denkt Diana und stellt aber sofort etwas enttäuscht fest: „Wenn er aus Kanada ist, bleibt er bestimmt nicht lange in Deutschland … Schade!“ Der schöne Mann bedankt sich für die Hilfe.
„Ich lerne gerade Deutsch, weil ich hier leben möchte“, erklärt er.
Dann schaut er auf die Uhr: „Ich muss gehen.“ „Ach, wenn er gehen MUSS, hat er bestimmt eine Freundin …“, spekuliert Diana.
„Mein Hund wartet auf mich, ich muss mit ihm spazieren gehen!“, fügt der Mann hinzu.
„Ein Tierliebhaber!“ schwärmt Diana.
Der schöne Mann möchte gerade los, aber er dreht sich noch ein letztes Mal um: „Vielleicht sehen wir uns wieder?“ „Gerne“, sagt Diana und schreibt ihm ihre Telefonnummer auf.
Heute hat er angerufen.

Seitdem schwebt Diana auf Wolke sieben.
Das Leben ist halt manchmal einfach perfekt.


https://learngerman.dw.com/de/auf-wolke-sieben-schweben/l-18745542/lm


