[[0-root-da-sagt-mann-so|Back to list]]

---
---

Alleine arbeitet man manchmal am besten. Denn wenn viele Menschen mit unterschiedlichen Meinungen und Methoden zusammen etwas machen wollen, kann das zu Schwierigkeiten führen. Das sagt auch ein deutsches Sprichwort.
  
Katie hat sich einen neuen Kleiderschrank gekauft. Er ist sehr groß, und es ist nicht leicht, ihn aufzubauen. 

Zum Glück haben Julia, Robin und Dennis angeboten, ihr zu helfen. Sie stehen zu viert vor dem Schrank, Katie liest die Anleitung. 

„Ich brauche keine Anleitung“, sagt Julia und will gleich Löcher in die Rückwand bohren. 

„Moment, wir anfangen|fangen mit den Türen an“, ruft Robin und nimmt die Türen in die Hand. 

„Wir müssen erst diese Bretter hier zusammenschrauben“, sagt Dennis und greift nach den Schrauben. 

„Warte!“, ruft Katie, „wenn du die Bretter zusammenschraubst und Robin die Türen so herum hält und Julia an dieser Stelle bohrt, dann passt das alles zum Schluss nicht zusammen.“ 

Aber alle machen so weiter, wie sie begonnen haben. Niemand achtet darauf, was die anderen tun. 

„Ich sollte den Schrank besser alleine aufbauen!“, denkt Katie. „Viele Köche verderben den brei.“ 

Sie atmet tief ein. „Stopp!“, ruft sie. „Ihr macht den Schrank noch kaputt!“ 

Julia, Robin und Dennis sehen sich an. Was ist denn mit Katie los? „Wir wollten dir doch nur helfen“, sagen sie und schütteln verständnislos die Köpfe.

https://learngerman.dw.com/de/viele-k%C3%B6che-verderben-den-brei/l-36385982/lm