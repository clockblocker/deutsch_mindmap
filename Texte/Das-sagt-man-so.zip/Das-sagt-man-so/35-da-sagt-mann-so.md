[[0-root-da-sagt-mann-so|Back to list]]

---
---

Es gibt ein Land, das so schön ist, dass selbst Gott dort leben möchte. Die Menschen in diesem Land genießen den Tag, haben ganz viel Geld und keine Sorgen. Zumindest behauptet das eine Redewendung.
  
Sabrina ist genervt und ein wenig neidisch: Ihre Freundin Tina fährt mindestens dreimal im Jahr in Urlaub, geht jedes Wochenende shoppen und auch sonst ist ihr Leben wie aus einem Märchenbuch.

Klar, Tina verdient ja auch viel Geld als Managerin. Sabrina findet: Tina lebt wie Gott in Frankreich! Das bedeutet natürlich nicht, dass sie eine Göttin ist oder dass sie in Frankreich lebt.

Tina ist eine ganz normale Frau. Sie lebt in Köln und fliegt am liebsten nach Australien. Sie kann sich einfach alles Leisten und genießt das Leben. So vorstellen|stellen sich manche Leute das Leben in Frankreich vor. 

Sonne, Liebe in der Luft, Rotwein, guter Käse und schöne Landschaften, den ganzen Tag „oh, là là“ rufen und es sich gutgehen lassen. Ob das realistisch ist? Fragt doch mal einen Franzosen …

 https://learngerman.dw.com/de/leben-wie-gott-in-frankreich/l-18745522/lm