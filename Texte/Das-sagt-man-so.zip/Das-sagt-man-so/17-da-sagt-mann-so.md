[[0-root-da-sagt-mann-so|Back to list]]

---
---

https://learngerman.dw.com/de/einen-kater-haben/l-18745482/lm

Es fängt meistens so an: Die Party ist gut, alle Freunde sind da, der Alkohol fließt, die Stimmung steigt.
Es ist seit langer Zeit die beste Party! Aber irgendwann wacht man auf, und er ist da! Wer hat ihn bloß gerufen?
Marie war gestern mit ihren Freunden aus. Eigentlich wollten sie irgendwo gemütlich sitzen und ein Bier trinken.
Doch dann kamen immer mehr Freunde dazu, und am Ende landeten alle auf einer coolen Party.
Der DJ legte genau die richtige Musik auf, die Stimmung war fantastisch, und irgendwie hatte Marie andauernd einen neuen Drink in der Hand.
Wann sie nach Hause kam, weiß sie heute Morgen nicht mehr, aber … aua … diese Kopfschmerzen!
Die müssen doch wirklich nicht sein!
Und … aua … jetzt klingelt auch noch das Telefon.
„Hallo, Marie?“ Es ist Bettina, Maries Freundin.
„Ich wollte nur wissen, ob es dir gut geht und du gestern gut nach Hause gekommen bist.“ „Ach ja ...“, seufzt Marie: „… alles gut.
Wenn nur diese Kopfschmerzen nicht wären.
Und mein Magen erst … Ich glaube, das letzte Bier war schlecht.“ Bettina lacht: „Tja, da hast du wohl einen richtigen Kater!
Trink viel Wasser und iss was Salziges.
Gute Besserung!“ Marie legt auf.
Auf diesen Kater könnte sie gut verzichten.
In Maries Fall ist das nämlich kein süßes Haustier, sondern die Bezeichnung für die schmerzhaften Folgen von zu viel Alkohol.
„Aua! Ich werde nie wieder trinken!“, sagt Marie.
„Das werden wir sehen …“, sagt der Kater.

