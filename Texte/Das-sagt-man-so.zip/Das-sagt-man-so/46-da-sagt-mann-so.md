[[0-root-da-sagt-mann-so|Back to list]]

---
---

 Wenn etwas brennt, kann man die Feuerwehr rufen oder einen Eimer Wasser holen. Gegen das Feuer unter den Fingernägeln hilft das aber nicht. Dann sollte man besser sagen, was man schon lange loswerden wollte.  
  
Jenny ist Journalistin und schreibt gerne über Prominente und Bekannte Personen. 

Heute war sie besonders aufgeregt, denn sie hatte einen Interviewtermin mit einem bekannten Schauspieler. Leider hatte sie nur 20 Minuten Zeit für das Interview. 

Nach 15 Minuten redete der Schauspieler immer noch ohne Punkt und Komma über seinen neuen Film, ohne dass Jenny überhaupt eine Frage stellen konnte. 

Der Manager des Schauspielers kam herein, um Bescheid zu sagen, dass Jenny nur noch fünf Minuten Zeit hatte. 
„Falls Ihnen noch eine Frage unter den Nägeln brennt, sollten Sie diese jetzt stellen …“, riet er ihr. 

„Mir brennt tatsächlich etwas sehr unter den Nägeln“, sagte Jenny, „könnte es sein, dass Ihre drei Ehen daran zerbrochen sind, dass sie zu viel geredet haben?“ 

Eine Antwort auf diese Frage bekam Jenny leider nicht. Dabei hätte sie diese wirklich sehr interessiert.

 https://learngerman.dw.com/de/unter-den-fingernaegeln-brennen/l-19068081/lm