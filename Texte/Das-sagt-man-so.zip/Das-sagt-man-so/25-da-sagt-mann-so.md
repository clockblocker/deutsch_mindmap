[[0-root-da-sagt-mann-so|Back to list]]

---
---

https://learngerman.dw.com/de/im-eimer-sein/l-18829838/lm