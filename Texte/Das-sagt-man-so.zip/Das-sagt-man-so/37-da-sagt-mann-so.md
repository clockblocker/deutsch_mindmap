[[0-root-da-sagt-mann-so|Back to list]]

---
---

Träume und Wünsche hat jeder. Wenn Menschen zum Beispiel nicht den Traum gehabt hätten, wie die Vögel zu fliegen, wäre das Flugzeug nie erfunden worden. Aber manche Träume sollte man nicht um jeden Preis verfolgen.

Lauras Traum war es schon immer, ein Haus mit Garten zu haben. 20 Jahre lang legte an|legte sie ihr Geld in Aktien an, um sich ein Haus Leisten zu können. 

Über die Jahre kam eine schöne Summe zusammen, und Laura studierte bereits die Immobilienangebote in der Zeitung und im Internet. 

Leider hatte sie nicht mit der Finanzkrise gerechnet. Innerhalb von wenigen Wochen war ihr gesamtes Vermögen auf die Hälfte zusammengeschrumpft. Laura war verzweifelt. 

Aus der Traum vom eigenen Haus mit Garten! Da bekam sie einen Anruf von ihrer Tante Gertrude. 

„Liebe Laura“, sagte sie am Telefon, „ich weiß, wie traurig du bist wegen der Sache mit dem Haus. Ich möchte dir einen Vorschlag machen. Wie du weißt, ziehe ich bald ins Altersheim. Ich anbieten|biete dir meine kleine Wohnung in der Altstadt an. Sie ist nicht besonders groß, aber dafür bist du im schönsten Teil der Stadt, und es ist ein riesiger Park in der Nähe, wo du spazieren gehen kannst. Finanziell könnten wir uns bestimmt einigen.“ 

Da musste Laura nicht lange überlegen. „Ich möchte dein Angebot annehmen“, antwortete sie, „denn wenn ich warte, bis ich wieder genug Geld habe, muss auch ich ins Altersheim. Und wie sagt man so schön? Besser den Spatz in der Hand als die Taube auf dem Dach.“

https://learngerman.dw.com/de/lieber-den-spatz-in-der-hand-als-die-taube-auf-dem-dach/l-19120362/lm