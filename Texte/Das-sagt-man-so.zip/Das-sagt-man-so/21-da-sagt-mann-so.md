[[0-root-da-sagt-mann-so|Back to list]]

---
---

https://learngerman.dw.com/de/etwas-an-den-nagel-haengen/l-19068114/lm