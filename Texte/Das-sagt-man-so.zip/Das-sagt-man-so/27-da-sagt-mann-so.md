[[0-root-da-sagt-mann-so|Back to list]]

---
---

Wer war nicht schon einmal in einer schwierigen Lage? Gut, wenn man dann nicht alleine ist. Denn wenn die anderen dieselben Ziele und Interessen haben, findet man zusammen bestimmt eine Lösung.  

Alex und Daniel haben nächste Woche eine wichtige Prüfung. Wenn sie diese Prüfung nicht bestehen, dürfen sie nicht weiter an der Universität bleiben. Und der Professor ist sehr anspruchsvoll: Er macht die Prüfungen gerne sehr schwer, damit viele sie nicht bestehen. 

Alex und Daniel sind deshalb sehr nervös, sie wollen die Prüfung unbedingt schaffen. 
„Sollen wir zusammen lernen?“, fragt Alex. 
„Besser nicht“, antwortet Daniel, „ich lerne lieber alleine. Dann kann ich mich besser konzentrieren.“ 

Aber Alex will nicht alleine lernen und sagt:
„Lass uns zusammenarbeiten! Wir sitzen doch in einem Boot. Wir können bestimmt voneinander lernen.“ 
Daniel denkt nach. 
„Vielleicht hast du recht“, sagt er, „zu zweit sieht man mehr als allein.“ 

Und tatsächlich: Die beiden lernen viel voneinander. Hoffentlich reicht das auch für die Prüfung!

https://learngerman.dw.com/de/in-einem-boot-sitzen/l-36042334/lm