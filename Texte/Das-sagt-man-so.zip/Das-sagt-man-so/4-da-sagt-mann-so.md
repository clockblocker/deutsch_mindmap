[[0-root-da-sagt-mann-so|Back to list]]

---
---

In der C1 Schreiben/misc/Regel ist es gefährlich, wenn das Eis bricht, zum Beispiel auf einem zugefrorenen See. Anderswo ist das aber sehr erwünscht. Ein Abend kann dann schon mal viel entspannter verlaufen.
  
Miriams Freunde sind neugierig: Heute Abend will sie ihren neuen Freund Sebastian zum Grillen mitbringen. Den wollen sie natürlich kennenlernen. 

Sebastian selbst sieht das weniger entspannt. Er ist ziemlich nervös, als sie auf die Gruppe zugehen, die sich um den Grill versammelt hat. 

Die Begrüßung läuft noch ganz gut: Miriam vorstellen|stellt ihn allen vor. Sie scheinen nett zu sein, aber ein längeres Gespräch entwickelt sich nicht. Und Miriams beste Freundin erklärt dann auch noch, dass sie unbedingt etwas mit ihr besprechen muss – unter vier Augen! 

Sebastian steht ein bisschen verloren da, als ihn einer von Miriams Freunden anspricht: „Hey, ich bin Nasim. Hilfst du mir mal mit den Getränken? Die sind noch im Auto.“ 

Sebastian ist erleichtert, dass er etwas tun kann: „Klar, gerne.“ 
Auf dem Weg zum Auto sagt Nasim: „Miriam hat erzählt, du machst auch Judo.“ 
Sebastian lächelt: „Ja, das stimmt. Du auch?“ 

Als die beiden mit den Getränkekisten zurückkommen, unterhalten sie sich lebhaft.
Die anderen kommen dazu und abnehmen|nehmen den beiden ein paar von den schweren Kisten ab. 
Miriam ist erleichtert: Das Eis zwischen Sebastian und ihren Freunden ist gebrochen!	

https://learngerman.dw.com/de/das-eis-brechen/l-19536464

🧊🤝 das Eis brechen *Redewendung*
🐛🚫 da ist der Wurm drin *Redewendung*
🎩🧩🤹‍♂️ alles unter einen Hut bringen *Redewendung*
👖🤏 den Gürtel enger schnallen *Redewendung*
☁️7️⃣🥰 auf Wolke sieben schweben *Redewendung*
