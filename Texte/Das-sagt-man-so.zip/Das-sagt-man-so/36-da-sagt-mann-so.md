[[0-root-da-sagt-mann-so|Back to list]]

---
---

Woher kommt die Liebe, wohin geht die Liebe? Das ist ein großes Geheimnis. Wenn man aber einem Sprichwort glaubt, dann hat die Liebe ganz viel mit einem Organ zu tun, das wir normalerweise nicht romantisch finden.

Emilie und Adrian kennen sich noch nicht so lange, aber es ist ganz klar: Sie finden einander interessant. Adrian ist sich nicht ganz sicher, wie Emilies Gefühle für ihn sind. 

Mag sie ihn oder hat sie stärkere Gefühle für ihn?  Zeit für einen kleinen Trick. Denn Adrians Großvater hat immer gesagt: „Mein Junge, Liebe geht durch den Magen! Jedes Mal, wenn deine Großmutter und ich gemütlich in der Küche sitzen und zusammen etwas Gutes essen, verliebe ich mich noch mehr in sie.“ 

Also lädt Adrian Emilie zum Essen ein. Es gibt Spaghetti mit leckerer Soße und selbst gemachtes Eis. Während die beiden am Tisch sitzen und das Eis löffeln, schaut Adrian Emilie tief in die Augen und sie stellt fest: Ich hab diesen Mann zum fressen gern. 

Liegt es wirklich am Essen oder an Adrians braunen Augen? Wer weiß … Auf jeden Fall hat es funktioniert: Emilie und Adrian heiraten nächstes Wochenende. Und ihr seid herzlich eingeladen.

https://learngerman.dw.com/de/liebe-geht-durch-den-magen/l-18745472/lm